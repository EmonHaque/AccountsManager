﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Common
{
    public class BookName
    {
        public const string NonCurrentAsset = "Non Current Assets";
        public const string CurrentAsset = "Current Assets";
        public const string Expense = "Expenses";
        public const string NonCurrentLiability = "Non Current Liabilities";
        public const string CurrentLiability = "Current Liabilities";
        public const string Fund = "Fund";
        public const string Income = "Incomes";
    }
}
