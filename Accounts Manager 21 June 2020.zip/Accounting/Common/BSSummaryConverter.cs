﻿using Accounting.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace Accounting.Common
{
    public class BSSummaryConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            int sum = 0;
            var group = value as CollectionViewGroup;
            if (group.IsBottomLevel)
            {
                sum = ((IEnumerable<object>)group.Items).OfType<Balance>().Sum(x => x.Amount);
            }
            else
            {
                foreach (CollectionViewGroup subGroup in group.Items)
                {
                    sum += ((IEnumerable<object>)subGroup.Items).OfType<Balance>().Sum(x => x.Amount);
                }
            }
            return sum;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
