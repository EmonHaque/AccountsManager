﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Common
{
    public class ControlName
    {
        public const string Cash = "Cash";
        public const string Receivable = "Receivables";
        public const string Payable = "Payables";
    }
}
