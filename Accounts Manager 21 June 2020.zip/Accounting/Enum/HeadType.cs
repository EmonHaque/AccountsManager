﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Enum
{
    public enum HeadType
    {
        Asset,
        Liability,
        Income,
        Expense,
        Fund
    }
}
