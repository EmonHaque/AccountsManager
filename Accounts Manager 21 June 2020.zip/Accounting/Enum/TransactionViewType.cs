﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Enum
{
    public enum TransactionViewType
    {
        General,
        Adjustment
    }
}
