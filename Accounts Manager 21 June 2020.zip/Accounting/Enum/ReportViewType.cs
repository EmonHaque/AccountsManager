﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Enum
{
    public enum ReportViewType
    {
        ControlLedger,
        Ledger,
        SubLedger,
        PartyLedger,
        MemberLedger,
        IncomeExpense,
        BalanceSheet,
        Journal,
        CashFlow,
        ReceiptPayment
    }
}
