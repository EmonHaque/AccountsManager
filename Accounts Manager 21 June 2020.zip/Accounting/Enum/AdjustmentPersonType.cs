﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Enum
{
    public enum AdjustmentPersonType
    {
        Party,
        Member,
        None
    }
}
