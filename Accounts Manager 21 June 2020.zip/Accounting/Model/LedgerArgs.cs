﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Model
{
    class LedgerArgs
    {
        public string Dr { get; set; }
        public string Cr { get; set; }
        public int Id { get; set; }
    }
}
