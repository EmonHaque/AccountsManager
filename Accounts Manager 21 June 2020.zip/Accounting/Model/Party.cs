﻿using Accounting.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Accounting.Model
{
    public class Party : INotifyPropertyChanged
    {
        int id;
        public int Id { get => id; set { id = value; OnPropertyChanged(); } }

        int groupId;
        public int GroupId { get => groupId; set { groupId = value; OnPropertyChanged(); } }

        string name;
        public string Name { get => name; set { name = value; OnPropertyChanged(); } }

        string address;
        public string Address { get => address; set { address = value; OnPropertyChanged(); } }

        string contactNo;
        public string ContactNo { get => contactNo; set { contactNo = value; OnPropertyChanged(); } }

        public bool IsInsertValid()
        {
            return GroupId > 0 && 
                !string.IsNullOrWhiteSpace(Name) &&
                MainVM.Parties.FirstOrDefault(x => x.Name.ToLower() == Name.Trim().ToLower()) == null;
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
