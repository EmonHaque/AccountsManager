﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Model
{
    public class Journal
    {
        public DateTime Date { get; set; }
        public string Debit { get; set; }
        public string Credit { get; set; }
        public int Amount { get; set; }
        public string Narration { get; set; }
    }
}
