﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Model
{
    public class CashBalance
    {
        public int Beginning { get; set; }
        public int Ending { get; set; }
    }
}
