﻿using Accounting.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Accounting.Model
{
    public class Ledger : INotifyPropertyChanged
    {
        int id;
        public int Id { get => id; set { id = value; OnPropertyChanged(); } }

        int bookId;
        public int BookId { get => bookId; set { bookId = value; OnPropertyChanged(); } }

        int controlId;
        public int ControlId { get => controlId; set { controlId = value; OnPropertyChanged(); } }

        string name;
        public string Name { get => name; set { name = value; OnPropertyChanged(); } }

        string description;
        public string Description { get => description; set { description = value; OnPropertyChanged(); } }

        public bool IsInsertValid()
        {
            return BookId > 0 &&
                ControlId > 0 &&
                !string.IsNullOrWhiteSpace(Name) &&
                !string.IsNullOrWhiteSpace(Description) &&
                MainVM.Ledgers.Where(x => x.ControlId == ControlId).FirstOrDefault(x => x.Name.ToLower() == Name.Trim().ToLower()) == null;
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
