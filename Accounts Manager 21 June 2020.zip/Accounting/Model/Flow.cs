﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Model
{
    public class Flow
    {
        public string Type { get; set; }
        public string Head { get; set; }
        public int Amount { get; set; }
    }
}
