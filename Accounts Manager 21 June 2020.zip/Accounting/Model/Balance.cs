﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Model
{
    public class Balance
    {
        public string Category { get; set; }
        public string Book { get; set; }
        public string Ledger { get; set; }
        public int Amount { get; set; }
    }
}
