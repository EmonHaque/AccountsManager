﻿using Accounting.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;

namespace Accounting.Model
{
    public class TransactionTab
    {
        public string Name { get; set; }
        public TransactionViewType Type { get; set; }
        public UserControl View { get; set; }
        public string Geometry { get; set; }

        public TransactionTab(string name, TransactionViewType type, UserControl view, string geometry)
        {
            Name = name;
            Type = type;
            View = view;
            Geometry = geometry;
        }
    }
}
