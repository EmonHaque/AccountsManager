﻿using Accounting.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;

namespace Accounting.Model
{
    public class ReportTab
    {
        public string Name { get; set; }
        public ReportViewType Type { get; set; }
        public UserControl View { get; set; }
        public string Geometry { get; set; }

        public ReportTab(string name, ReportViewType type, UserControl view, string geometry)
        {
            Name = name;
            Type = type;
            View = view;
            Geometry = geometry;
        }
    }
}
