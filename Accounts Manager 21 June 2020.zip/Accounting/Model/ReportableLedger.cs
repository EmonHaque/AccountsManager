﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Model
{
    public class ReportableLedger
    {
        public DateTime Date { get; set; }
        public string Particulars { get; set; }
        public int Debit { get; set; }
        public int Credit { get; set; }
        public int Balance { get; set; }
        public string Narration { get; set; }
    }
}
