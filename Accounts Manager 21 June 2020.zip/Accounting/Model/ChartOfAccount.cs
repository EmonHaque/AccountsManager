﻿using Accounting.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Model
{
    public class ChartOfAccount
    {
        public Book Book { get; set; }
        public OCollection<ControlLedgers> ControlLedgers { get; set; }
        public ChartOfAccount() => ControlLedgers = new OCollection<ControlLedgers>();
    }

    public class ControlLedgers
    {
        public ControlLedger ControlLedger { get; set; }
        public OCollection<Ledgers> Ledgers { get; set; }
        public ControlLedgers() => Ledgers = new OCollection<Ledgers>();

    }

    public class Ledgers
    {
        public Ledger Ledger { get; set; }
        public OCollection<SubLedger> SubLedgers { get; set; }
        public Ledgers() => SubLedgers = new OCollection<SubLedger>();

    }
}
