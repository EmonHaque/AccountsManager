﻿using Accounting.Enum;
using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Model
{
    public class Adjustment
    {
        public DateTime Date { get; set; }
        public AdjustLedgers Debit { get; set; }
        public AdjustLedgers Credit { get; set; }
        public int Amount { get; set; }
        public string Narration { get; set; }
        public Adjustment()
        {
            Date = DateTime.Today;
            Debit = new AdjustLedgers();
            Credit = new AdjustLedgers();
        }
    }

    public class AdjustLedgers
    {
        public ControlLedger Control { get; set; }
        public Ledger Ledger { get; set; }
        public SubLedger SubLedger { get; set; }
        public Party Party { get; set; }
        public Member Member { get; set; }
        public AdjustmentPersonType Person { get; set; }

        public AdjustLedgers()
        {
            Control = new ControlLedger();
            Ledger = new Ledger();
            SubLedger = new SubLedger();
            Party = new Party();
            Member = new Member();
            Person = AdjustmentPersonType.Party;
        }
    }
}
