﻿using Accounting.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Accounting.Model
{
    public class ControlLedger : INotifyPropertyChanged
    {

        int id;
        public int Id { get => id; set { id = value; OnPropertyChanged(); } }

        int bookId;
        public int BookId { get => bookId; set { bookId = value; OnPropertyChanged(); } }

        string name;
        public string Name { get => name; set { name = value; OnPropertyChanged(); } }

        public bool IsInsertValid()
        {
            return BookId > 0 && 
                !string.IsNullOrWhiteSpace(Name) &&
                MainVM.ControlLedgers.Where(x => x.BookId == BookId).FirstOrDefault(x => x.Name.ToLower() == Name.Trim().ToLower()) == null;
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
