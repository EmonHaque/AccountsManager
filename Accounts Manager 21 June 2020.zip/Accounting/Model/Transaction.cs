﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Accounting.Model
{
    public class Transaction
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public int DrBook { get; set; }
        public int CrBook { get; set; }
        public int DrControl { get; set; }
        public int CrControl { get; set; }
        public int DrLedger { get; set; }
        public int CrLedger { get; set; }
        public int DrSubLedger { get; set; }
        public int CrSubLedger { get; set; }
        public int DrPartyGroup { get; set; }
        public int CrPartyGroup { get; set; }
        public int DrParty { get; set; }
        public int CrParty { get; set; }
        public int DrMember { get; set; }
        public int CrMember { get; set; }
        public int Amount { get; set; }
        public string Narration { get; set; }
    }
}
