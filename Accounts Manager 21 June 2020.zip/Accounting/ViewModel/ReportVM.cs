﻿using Accounting.Common;
using Accounting.Enum;
using Accounting.Model;
using Accounting.View.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;
using System.Text;

namespace Accounting.ViewModel
{
    public class ReportVM : INotifyPropertyChanged
    {
        LedgerArgs lArgs;
        BookType bookType;
        ReportDates dates;
        ReportTab selectedTab;
        int totalDebit, totalCredit, eoioe;
        List<ReportableLedger> ledgerReportables;
        List<Balance> balanceSheet;
        List<IncomeExpense> incomeExpenses;
        List<Flow> cashSummary;
        CashBalance cashBalance;
        List<Journal> journals;

        public List<Journal> Journals { get => journals; set { journals = value; OnPropertyChanged(); } }
        public CashBalance CashBalance { get => cashBalance; set { cashBalance = value; OnPropertyChanged(); } }      
        public List<Flow> CashSummary { get => cashSummary; set { cashSummary = value; OnPropertyChanged(); } }
        public List<IncomeExpense> IncomeExpenses { get => incomeExpenses; set { incomeExpenses = value; OnPropertyChanged(); } }
        public int EOIOE { get => eoioe; set { eoioe = value; OnPropertyChanged(); } }
        public List<Balance> BalanceSheet { get => balanceSheet; set { balanceSheet = value; OnPropertyChanged(); } }
        public ReportDates Dates { get => dates; set { dates = value; OnPropertyChanged(); } }     
        public int TotalDebit { get => totalDebit; set { totalDebit = value; OnPropertyChanged(); } }
        public int TotalCredit { get => totalCredit; set { totalCredit = value; OnPropertyChanged(); } }  
        public List<ReportableLedger> LedgerReportables { get => ledgerReportables; set { ledgerReportables = value; OnPropertyChanged(); } }
        public ReportTab SelectedTab
        {
            get => selectedTab;
            set
            {
                selectedTab = value;
                OnPropertyChanged();
                if (MainVM.SelectedIcon != null && MainVM.SelectedIcon.Name == Constants.Report) read();
            }
        }
        
        public List<ReportTab> Tabs { get; set; }
        public Command RefreshReport { get; set; }

        public ReportVM()
        {
            subscribe();
            initializeCommands();
            initializeTabs();
            lArgs = new LedgerArgs();
            Dates = new ReportDates() { From = DateTime.Today.AddMonths(-6) };
        }

        void initializeCommands()
        {
            RefreshReport = new Command(refreshReport, (o) => true);
        }

        void initializeTabs()
        {
            Tabs = new List<ReportTab>()
            {
                new ReportTab("Control Ledger", ReportViewType.ControlLedger, new ControlLedgerView() { DataContext = this }, Constants.ControlLedgerIcon),
                new ReportTab("Ledger", ReportViewType.Ledger, new LedgerView() { DataContext = this }, Constants.LedgerIcon),
                new ReportTab("Sub Ledger", ReportViewType.SubLedger, new SubLedgerView() { DataContext = this }, Constants.SubLedgerIcon),
                new ReportTab("Party Ledger", ReportViewType.PartyLedger, new PartyLedgerView() { DataContext = this }, Constants.PartyLedgerIcon),
                new ReportTab("Member Ledger", ReportViewType.MemberLedger, new MemberLedgerView() { DataContext = this }, Constants.MemberLedgerIcon),
                new ReportTab("Income Expense", ReportViewType.IncomeExpense, new IncomeExpenseView() { DataContext = this }, Constants.ISIcon),
                new ReportTab("Balance Sheet", ReportViewType.BalanceSheet, new BalanceSheetView() { DataContext = this }, Constants.BSIcon),
                new ReportTab("Journal", ReportViewType.Journal, new JournalView() { DataContext = this }, Constants.JournalIcon),
                new ReportTab("Cash Flow", ReportViewType.CashFlow, new CashFlowView() { DataContext = this }, Constants.CashFlowIcon),
                new ReportTab("ReceiptPayment", ReportViewType.ReceiptPayment, new ReceiptPaymentView() { DataContext = this }, Constants.ReceiptPaymentIcon)
            };
        }

        void subscribe()
        {
            MainVM.OnSelectedControlLedgerChanged += readData;
            MainVM.OnSelectedLedgerChanged += readData;
            MainVM.OnSelectedSubLedgerChanged += readData;
            MainVM.OnSelectedPartyChanged += readData;
            MainVM.OnSelectedMemberChanged += readData;
        }

        void read()
        {
            switch (SelectedTab.Type)
            {
                case ReportViewType.ControlLedger:
                    if (MainVM.SelectedControlLedger != null) readData(MainVM.SelectedControlLedger);
                    break;
                case ReportViewType.Ledger:
                    if (MainVM.SelectedLedger != null) readData(MainVM.SelectedLedger);
                    break;
                case ReportViewType.SubLedger:
                    if (MainVM.SelectedSubLedger != null) readData(MainVM.SelectedSubLedger);
                    break;
                case ReportViewType.PartyLedger:
                    if (MainVM.SelectedParty != null) readData(MainVM.SelectedParty);
                    break;
                case ReportViewType.MemberLedger:
                    if (MainVM.SelectedMember != null) readData(MainVM.SelectedMember);
                    break;
                case ReportViewType.IncomeExpense:
                    getIncomeExpense();
                    break;
                case ReportViewType.BalanceSheet:
                    getBalanceSheet();
                    break;
                case ReportViewType.Journal:
                    getJournal();
                    break;
                case ReportViewType.CashFlow:
                    string cfQuery = $@"with t0 as (
                                    	select DrBook, CrBook, DrControl, CrControl, DrLedger, CrLedger, Amount from Transactions
                                    	where 6 in (DrControl, CrControl)
                                    	and Date between '{Dates.From.ToString("yyyy-MM-dd")}' and '{Dates.To.ToString("yyyy-MM-dd")}'
                                    ),
                                    t1 (Book, Control, Ledger, Amount) as (
                                    	select CrBook, CrControl, CrLedger, sum(Amount) from t0
                                    	where DrControl = 6
                                    	group by CrControl, CrLedger
                                    ),
                                    t2 (Book, Control, Ledger, Amount) as (
                                    	select DrBook, DrControl, DrLedger, -1*sum(Amount) from t0
                                    	where CrControl = 6
                                    	group by DrControl, DrLedger
                                    ),
                                    t3 as (select * from t1 union all select * from t2),
                                    t4 as (
                                    	select case when Ledger is null then Book else (select BookId from ControlLedgers where Name = l.Name) end Book,
                                    		   case when l.Name is null then c.Name else l.Name end Head, 
                                    	Amount from t3
                                    	left join ControlLedgers c on c.Id = Control
                                    	left join Ledgers l on l.Id = Ledger
                                    )
                                    select case 
                                    	when Book in (3, 7) then 'Operating'
                                    	when Book = 1 then 'Investing'
                                    	when book in (4, 6) then 'Financing'
                                    	end Type, Head, Amount from t4";
                    getCashSummary(cfQuery);
                    break;
                case ReportViewType.ReceiptPayment:
                    string rpQuery = $@"with t0 as (
                                    	select DrBook, CrBook, DrControl, CrControl, DrLedger, CrLedger, Amount from Transactions
                                    	where 6 in (DrControl, CrControl)
                                    	and Date between '{Dates.From.ToString("yyyy-MM-dd")}' and '{Dates.To.ToString("yyyy-MM-dd")}'
                                    ),
                                    t1 (Type, Book, Control, Ledger, Amount) as (
                                    	select 'Receipt', CrBook, CrControl, CrLedger, sum(Amount) from t0
                                    	where DrControl = 6
                                    	group by CrControl, CrLedger
                                    ),
                                    t2 (Type, Book, Control, Ledger, Amount) as (
                                    	select 'Payment', DrBook, DrControl, DrLedger, sum(Amount) from t0
                                    	where CrControl = 6
                                    	group by DrControl, DrLedger
                                    ),
                                    t3 as (select * from t1 union all select * from t2),
                                    t4 as (
                                    	select Type,
                                    		   case when l.Name is null then c.Name else l.Name end Head, 
                                    	Amount from t3
                                    	left join ControlLedgers c on c.Id = Control
                                    	left join Ledgers l on l.Id = Ledger
                                    )
                                    select * from t4";
                    getCashSummary(rpQuery);
                    break;
            }
        }

        void getJournal()
        {
            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText =$@"select tn.Date,
                                    	b1.Name || ' -> ' || c1.Name || coalesce(' -> ' || l1.Name, '') || coalesce(' -> ' || s1.Name, '') || coalesce(' -> ' || p1.Name, '') || coalesce(' -> ' || m1.Name, '') Debit,
                                    	b2.Name || ' -> ' || c2.Name || coalesce(' -> ' || l2.Name, '') || coalesce(' -> ' || s2.Name, '') || coalesce(' -> ' || p2.Name, '') || coalesce(' -> ' || m2.Name, '') Credit,
                                    tn.Amount, Narration from Transactions tn
                                    left join Books b1 on b1.Id = tn.DrBook
                                    left join Books b2 on b2.Id = tn.CrBook
                                    left join ControlLedgers c1 on c1.Id = tn.DrControl
                                    left join ControlLedgers c2 on c2.Id = tn.CrControl
                                    left join Ledgers l1 on l1.Id = tn.DrLedger
                                    left join Ledgers l2 on l2.Id = tn.CrLedger
                                    left join SubLedgers s1 on s1.Id = tn.DrSubLedger
                                    left join SubLedgers s2 on s2.Id = tn.CrSubLedger
                                    left join Parties p1 on p1.Id = tn.DrParty
                                    left join Parties p2 on p2.Id = tn.CrParty
                                    left join Members m1 on m1.Id = tn.DrMember
                                    left join Members m2 on m2.Id = tn.CrMember
                                    where Date between '{Dates.From.ToString("yyyy-MM-dd")}' and '{Dates.To.ToString("yyyy-MM-dd")}'";

            var journals = new List<Journal>();
            SQLHelper.connection.Open();
            var reader = command.ExecuteReader();

            while (reader.Read())
            {
                journals.Add(new Journal()
                {
                    Date = reader.GetDateTime(0),
                    Debit = reader.GetString(1),
                    Credit = reader.GetString(2),
                    Amount = reader.GetInt32(3),
                    Narration = reader.IsDBNull(4) ? "No Explanation" : reader.GetString(4)
                });
            }
            SQLHelper.connection.Close();
            Journals = journals;
        }

        void getCashSummary(string query)
        {
            var balanceQuery = $@"with t0 as (
                                	select coalesce(sum(case when DrControl = 6 then Amount end), 0) -
                                		   coalesce(sum(case when CrControl = 6 then Amount end), 0)
                                	from Transactions where 6 in (DrControl, CrControl) and Date < '{Dates.From.ToString("yyyy-MM-dd")}'
                                ),
                                t1 as(
                                	select coalesce(sum(case when DrControl = 6 then Amount end), 0) -
                                		   coalesce(sum(case when CrControl = 6 then Amount end), 0)
                                	from Transactions where 6 in (DrControl, CrControl) and Date <= '{Dates.To.ToString("yyyy-MM-dd")}'
                                )
                                select (select * from t0) Beginning, (select * from t1) Ending;";

            var balance = new CashBalance();
            var summary = new List<Flow>();

            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText = balanceQuery + query;
            SQLHelper.connection.Open();
            var reader = command.ExecuteReader();
            reader.Read();
            balance.Beginning = reader.GetInt32(0);
            balance.Ending = reader.GetInt32(1);

            reader.NextResult();
            while (reader.Read())
            {
                summary.Add(new Flow()
                {
                    Type = reader.GetString(0),
                    Head = reader.GetString(1),
                    Amount = reader.GetInt32(2),
                });
            }
            SQLHelper.connection.Close();
            CashBalance = balance;
            CashSummary = summary;
        }

        void getIncomeExpense()
        {
            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText = $@"with t0 as (
                                	select DrBook, CrBook, DrControl, CrControl, Amount from Transactions
                                	where DrBook in (3, 7) or CrBook in (3, 7)
                                	and Date between '{Dates.From.ToString("yyyy-MM-dd")}' and '{Dates.To.ToString("yyyy-MM-dd")}'
                                ),
                                t1 (Book, Control, Amount) as (
                                	select DrBook, DrControl, sum(Amount) from t0
                                	where DrBook in (3, 7)
                                	group by DrBook, DrControl
                                ),
                                t2 (Book, Control, Amount) as (
                                	select CrBook, CrControl, -1*sum(Amount) from t0
                                	where CrBook in (3, 7)
                                	group by CrBook, CrControl
                                ),
                                t3 as (select * from t1 union all select * from t2)
                                select b.Name, c.Name, sum(case when Book = 3 then 1 else -1 end * Amount) Amount from t3
                                left join Books b on b.Id = Book
                                left join ControlLedgers c on c.Id = Control
                                group by b.Name, c.Name 
                                order by b.name desc";

            var balances = new List<IncomeExpense>();
            SQLHelper.connection.Open();
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                balances.Add(new IncomeExpense()
                {
                    Book = reader.GetString(0),
                    Ledger = reader.GetString(1),
                    Amount = reader.GetInt32(2)
                });
            }
            SQLHelper.connection.Close();

            var incomes = balances.Where(x => x.Book == BookName.Income).ToList();
            var expenses = balances.Where(x => x.Book == BookName.Expense).ToList();
            int income, expense;
            income = expense = 0;
            if (incomes.Count > 0) income = incomes.Sum(x => x.Amount);
            if (expenses.Count > 0) expense = expenses.Sum(x => x.Amount);
            EOIOE = income - expense;
            IncomeExpenses = balances;
        }

        void getBalanceSheet()
        {
            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText = $@"with t1(Id, Book, Control, Amount) as (
                             	select tn.DrBook, b1.Name, c1.Name, sum(tn.Amount) from Transactions tn
                             	left join Books b1 on b1.Id = tn.DrBook
                             	left join ControlLedgers c1 on c1.Id = tn.DrControl
                             	where tn.Date <= '{Dates.To.ToString("yyyy-MM-dd")}'
                             	group by DrBook, DrControl
                             ), t2 as (
                             	select tn.CrBook, b1.Name, c1.Name, -1*sum(tn.Amount) from Transactions tn
                             	left join Books b1 on b1.Id = tn.CrBook
                             	left join ControlLedgers c1 on c1.Id = tn.CrControl
                             	where tn.Date <= '{Dates.To.ToString("yyyy-MM-dd")}'
                             	group by CrBook, CrControl
                             ), t3 as(
                             	select * from t1 union all select * from t2
                             ), t4 as (
                             select Id, Book, Control, 
                             	sum(case when Id < 4 then 1 else -1 end * Amount) Amount
                             from t3 group by Book, Control
                             )
                             select * from t4 where Amount <> 0 order by Id;";

            var balances = new List<Balance>();
            SQLHelper.connection.Open();
            var reader = command.ExecuteReader();
            while (reader.Read())
            {
                balances.Add(new Balance()
                {
                    Category = reader.GetInt32(0) < 4 ? "Assets" : "Liabilities and Fund",
                    Book = reader.GetString(1),
                    Ledger = reader.GetString(2),
                    Amount = reader.GetInt32(3)
                });
            }
            SQLHelper.connection.Close();

            int income, expense; income = expense = 0;
            var x = balances.Where(x => x.Book == BookName.Income).ToList();
            var y = balances.Where(x => x.Book == BookName.Expense).ToList();
            if (x.Count > 0) income = x.Sum(x => x.Amount);
            if (y.Count > 0) expense = y.Sum(x => x.Amount);

            var eoioe = income - expense;
            balances = balances.Except(balances.Where(x => x.Book == BookName.Income || x.Book == BookName.Expense)).ToList();
            if(eoioe != 0)
            {
                balances.Add(new Balance()
                {
                    Category = "Liabilities and Fund",
                    Book = "Fund",
                    Ledger = "Excess of Income over Expense",
                    Amount = eoioe
                });
            }
            
            BalanceSheet = balances;
        }

        void readData(object o)
        {
            if(MainVM.SelectedIcon.Name == Constants.Report)
            {
                switch (o)
                {
                    case ControlLedger l:
                        if (SelectedTab.Type != ReportViewType.ControlLedger) return;
                        lArgs.Dr = "DrControl"; lArgs.Cr = "CrControl"; lArgs.Id = l.Id;
                        setBookType(l.BookId);
                        break;
                    case Ledger l:
                        if (SelectedTab.Type != ReportViewType.Ledger) return;
                        lArgs.Dr = "DrLedger"; lArgs.Cr = "CrLedger"; lArgs.Id = l.Id;
                        setBookType(l.BookId);
                        break;
                    case SubLedger l:
                        if (SelectedTab.Type != ReportViewType.SubLedger) return;
                        lArgs.Dr = "DrSubLedger"; lArgs.Cr = "CrSubLedger"; lArgs.Id = l.Id;
                        setBookType(l.BookId);
                        break;
                    case Party l:
                        if (SelectedTab.Type != ReportViewType.PartyLedger) return;
                        lArgs.Dr = "DrParty"; lArgs.Cr = "CrParty"; lArgs.Id = l.Id;
                        bookType = BookType.LiabilityIcomeOrNone;
                        break;
                    case Member l:
                        if (SelectedTab.Type != ReportViewType.MemberLedger) return;
                        lArgs.Dr = "DrMember"; lArgs.Cr = "CrMember"; lArgs.Id = l.Id;
                        bookType = BookType.LiabilityIcomeOrNone;
                        break;
                }
                
                setLedger(lArgs);
            }
        }

        void setBookType(int bookId)
        {
            if (bookId < 4) bookType = BookType.AssetOrExpense;
            else bookType = BookType.LiabilityIcomeOrNone;
        }

        void refreshReport(object o)
        {
            // keep query in variables
            switch (SelectedTab.Type)
            {
                case ReportViewType.ControlLedger:
                case ReportViewType.Ledger:
                case ReportViewType.SubLedger:
                case ReportViewType.PartyLedger:
                case ReportViewType.MemberLedger:
                    setLedger(lArgs);
                    break;
                case ReportViewType.IncomeExpense:
                    getIncomeExpense();
                    break;
                case ReportViewType.BalanceSheet:
                    getBalanceSheet();
                    break;
                case ReportViewType.Journal:
                    getJournal();
                    break;
                case ReportViewType.CashFlow:
                    string cfQuery = $@"with t0 as (
                                    	select DrBook, CrBook, DrControl, CrControl, DrLedger, CrLedger, Amount from Transactions
                                    	where 6 in (DrControl, CrControl)
                                    	and Date between '{Dates.From.ToString("yyyy-MM-dd")}' and '{Dates.To.ToString("yyyy-MM-dd")}'
                                    ),
                                    t1 (Book, Control, Ledger, Amount) as (
                                    	select CrBook, CrControl, CrLedger, sum(Amount) from t0
                                    	where DrControl = 6
                                    	group by CrControl, CrLedger
                                    ),
                                    t2 (Book, Control, Ledger, Amount) as (
                                    	select DrBook, DrControl, DrLedger, -1*sum(Amount) from t0
                                    	where CrControl = 6
                                    	group by DrControl, DrLedger
                                    ),
                                    t3 as (select * from t1 union all select * from t2),
                                    t4 as (
                                    	select case when Ledger is null then Book else (select BookId from ControlLedgers where Name = l.Name) end Book,
                                    		   case when l.Name is null then c.Name else l.Name end Head, 
                                    	Amount from t3
                                    	left join ControlLedgers c on c.Id = Control
                                    	left join Ledgers l on l.Id = Ledger
                                    )
                                    select case 
                                    	when Book in (3, 7) then 'Operating'
                                    	when Book = 1 then 'Investing'
                                    	when book in (4, 6) then 'Financing'
                                    	end Type, Head, Amount from t4";
                    getCashSummary(cfQuery);
                    break;
                case ReportViewType.ReceiptPayment:
                    string rpQuery = $@"with t0 as (
                                    	select DrBook, CrBook, DrControl, CrControl, DrLedger, CrLedger, Amount from Transactions
                                    	where 6 in (DrControl, CrControl)
                                    	and Date between '{Dates.From.ToString("yyyy-MM-dd")}' and '{Dates.To.ToString("yyyy-MM-dd")}'
                                    ),
                                    t1 (Type, Book, Control, Ledger, Amount) as (
                                    	select 'Receipt', CrBook, CrControl, CrLedger, sum(Amount) from t0
                                    	where DrControl = 6
                                    	group by CrControl, CrLedger
                                    ),
                                    t2 (Type, Book, Control, Ledger, Amount) as (
                                    	select 'Payment', DrBook, DrControl, DrLedger, sum(Amount) from t0
                                    	where CrControl = 6
                                    	group by DrControl, DrLedger
                                    ),
                                    t3 as (select * from t1 union all select * from t2),
                                    t4 as (
                                    	select Type,
                                    		   case when l.Name is null then c.Name else l.Name end Head, 
                                    	Amount from t3
                                    	left join ControlLedgers c on c.Id = Control
                                    	left join Ledgers l on l.Id = Ledger
                                    )
                                    select * from t4";
                    getCashSummary(rpQuery);
                    break;
                default:
                    break;
            }
           
        }

        void setLedger(LedgerArgs arg)
        {
            if (MainVM.SelectedIcon.Name != Constants.Report) return;

            var balanceQuery = $@"select
                                  coalesce(sum(case when {arg.Dr} = {arg.Id} then Amount end), 0) -
                                  coalesce(sum(case when {arg.Cr} = {arg.Id} then Amount end), 0) 
                                  from Transactions
                                  where {arg.Id} in ({arg.Dr}, {arg.Cr}) and Date < '{Dates.From.ToString("yyyy-MM-dd")}';";

            var dataQuery = $@"select tn.Date, 
                               case when tn.{arg.Cr} = {arg.Id} and tn.{arg.Dr} = {arg.Id} 
                                   then b1.Name || ' -> ' || c1.Name || coalesce(' -> ' || l1.Name, '') || coalesce(' -> ' || s1.Name, '') || coalesce(' -> ' || p1.Name, '') || coalesce(' -> ' || m1.Name, '')
                                   || ' <-||-> ' ||
                                   b2.Name || ' -> ' || c2.Name || coalesce(' -> ' || l2.Name, '') || coalesce(' -> ' || s2.Name, '') || coalesce(' -> ' || p2.Name, '') || coalesce(' -> ' || m2.Name, '')
                                   when tn.{arg.Cr} = {arg.Id} 
                                   then b1.Name || ' -> ' || c1.Name || coalesce(' -> ' || l1.Name, '') || coalesce(' -> ' || s1.Name, '') || coalesce(' -> ' || p1.Name, '') || coalesce(' -> ' || m1.Name, '')
                                   else b2.Name || ' -> ' || c2.Name || coalesce(' -> ' || l2.Name, '') || coalesce(' -> ' || s2.Name, '') || coalesce(' -> ' || p2.Name, '') || coalesce(' -> ' || m2.Name, '')
                               end Particulars,
                               	   case when tn.{arg.Dr} = {arg.Id} then tn.Amount end Debit,
                               	   case when tn.{arg.Cr} = {arg.Id} then tn.Amount end Credit,
                               tn.Narration from Transactions tn
                               left join Books b1 on b1.Id = tn.DrBook
                               left join Books b2 on b2.Id = tn.CrBook
                               left join ControlLedgers c1 on c1.Id = tn.DrControl
                               left join ControlLedgers c2 on c2.Id = tn.CrControl
                               left join Ledgers l1 on l1.Id = tn.DrLedger
                               left join Ledgers l2 on l2.Id = tn.CrLedger
                               left join SubLedgers s1 on s1.Id = tn.DrSubLedger
                               left join SubLedgers s2 on s2.Id = tn.CrSubLedger
                               left join Parties p1 on p1.Id = tn.DrParty
                               left join Parties p2 on p2.Id = tn.CrParty
                               left join Members m1 on m1.Id = tn.DrMember
                               left join Members m2 on m2.Id = tn.CrMember
                               where {arg.Id} in ({arg.Dr}, {arg.Cr})
                               and Date between '{Dates.From.ToString("yyyy-MM-dd")}' and '{Dates.To.ToString("yyyy-MM-dd")}'
                               order by Date;";

            var commandText = balanceQuery + dataQuery;
            var reportables = new List<ReportableLedger>();
            int totalDebit, totalCredit, rollingBalance;
            totalDebit = totalCredit = rollingBalance = 0;

            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText = commandText;

            SQLHelper.connection.Open();
            var reader = command.ExecuteReader();

            reader.Read();
            var beginningBalance = reader.GetInt32(0);
            if(beginningBalance != 0)
            {
                if (bookType != BookType.AssetOrExpense) beginningBalance *= -1;
                reportables.Add(new ReportableLedger()
                {
                    Date = Dates.From,
                    Particulars = "Balance b/d",
                    Balance = beginningBalance
                });
                rollingBalance = beginningBalance;
            }

            reader.NextResult();
            while (reader.Read())
            {
                var debit = reader.IsDBNull(2) ? 0 : reader.GetInt32(2);
                var credit = reader.IsDBNull(3) ? 0 : reader.GetInt32(3);
                var narration = reader.IsDBNull(4) ? "No Explanation" : reader.GetString(4);
                totalDebit += debit;
                totalCredit += credit;

                if (bookType == BookType.AssetOrExpense) rollingBalance = rollingBalance + debit - credit;
                else rollingBalance = rollingBalance - debit + credit;

                reportables.Add(new ReportableLedger()
                {
                    Date = reader.GetDateTime(0),
                    Particulars = reader.GetString(1),
                    Debit = debit,
                    Credit = credit,
                    Balance = rollingBalance,
                    Narration = narration
               });
            }
            SQLHelper.connection.Close();

            LedgerReportables = reportables;
            TotalDebit = totalDebit;
            TotalCredit = totalCredit;
        }

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
