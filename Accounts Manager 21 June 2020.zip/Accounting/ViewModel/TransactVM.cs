﻿using Accounting.Common;
using Accounting.Enum;
using Accounting.Model;
using Accounting.View.Transaction;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection.Metadata;
using System.Runtime.CompilerServices;
using System.Text;

namespace Accounting.ViewModel
{
    public class TransactVM : INotifyPropertyChanged
    {
        ControlLedger receivables, payables;
        public OCollection<SubLedger> CashAccounts { get; set; }
        public OCollection<Transaction> Transactions { get; set; }
        public OCollection<Transaction> Adjustments { get; set; }

        HeadType head;
        TransactionType transactionMode;
        int inCash;
        bool isMember, isPositive;
        Transaction transaction, adjustmentEntry;
        TransactionTab selectedTab;
        SubLedger selectedCashAccount;
        List<ControlLedger> revelantControls;
        Adjustment adjust;

        public Adjustment Adjust { get => adjust; set { adjust = value; OnPropertyChanged(); } }
        public List<ControlLedger> RelevantControls { get => revelantControls; set { revelantControls = value; OnPropertyChanged(); } }
        public SubLedger SelectedCashAccount { get => selectedCashAccount; set { selectedCashAccount = value; OnPropertyChanged(); } }
        public TransactionType TransactionMode { get => transactionMode; set { transactionMode = value; OnPropertyChanged(); } }        
        public HeadType Head 
        {
            get => head; 
            set 
            { 
                head = value; 
                OnPropertyChanged();
                if(MainVM.SelectedIcon != null && MainVM.SelectedIcon.Name == Constants.Transact)
                    setRelevantControls(value);
            } 
        }       
        public int InCash { get => inCash; set { inCash = value; OnPropertyChanged(); } }       
        public bool IsMember 
        { 
            get => isMember; 
            set 
            { 
                isMember = value; 
                OnPropertyChanged();
                if (value) MainVM.SelectedMember = MainVM.Members.FirstOrDefault();
                else MainVM.SelectedParty = MainVM.Parties.FirstOrDefault();
            } 
        }
        public bool IsPositive { get => isPositive; set { isPositive = value; OnPropertyChanged(); } }      
        public Transaction Transaction { get => transaction; set { transaction = value; OnPropertyChanged(); } }
        public Transaction AdjustmentEntry { get => adjustmentEntry; set { adjustmentEntry = value; OnPropertyChanged(); } }

        public Command AddGeneralEntry { get; set; }
        public Command PassGeneralEntry { get; set; }
        public Command AddAdjustmentEntry { get; set; }
        public Command PassAdjustmentEntry { get; set; }

        public TransactionTab SelectedTab
        {
            get => selectedTab;
            set
            {
                selectedTab = value;
                //reportType = value.Type;
                OnPropertyChanged();
                //if (value != null) read(null);
            }
        }
        public List<TransactionTab> Tabs { get; set; }

        public TransactVM()
        {
            initializeProperties();
            subscribe();
            initializeCommands();
            initializeTabs();
        }

        void initializeTabs()
        {
            Tabs = new List<TransactionTab>()
            {
                new TransactionTab("General", TransactionViewType.General, new GeneralView() { DataContext = this }, Constants.GeneralTransactionIcon),
                new TransactionTab("Adjustment", TransactionViewType.Adjustment, new AdjustmentView() { DataContext = this }, Constants.AdjustingTransactionIcon)

            };
        }

        void initializeProperties()
        {
            CashAccounts = new OCollection<SubLedger>();
            var cashId = MainVM.ControlLedgers.First(x => x.Name == ControlName.Cash).Id;
            var subLedger = MainVM.SubLedgers.FirstOrDefault(x => x.ControlId == cashId);
            if (subLedger != null)
            {
                CashAccounts = new OCollection<SubLedger>(MainVM.SubLedgers.Where(x => x.ControlId == cashId));
                SelectedCashAccount = CashAccounts.First();
            }
            Transactions = new OCollection<Transaction>();
            Adjustments = new OCollection<Transaction>();
            Transaction = new Transaction() { Date = DateTime.Today };
            AdjustmentEntry = new Transaction();
            Adjust = new Adjustment();
            Head = HeadType.Expense;
            receivables = MainVM.ControlLedgers.First(x => x.Name == ControlName.Receivable);
            payables = MainVM.ControlLedgers.First(x => x.Name == ControlName.Payable);
        }

        void subscribe()
        {
            MainVM.OnSelectedIconChanged += iconChangedHandler;
            AddVM.OnSubLedgerAdded += subLedgerAddedHandler;
        }

        void initializeCommands()
        {
            AddGeneralEntry = new Command(addGeneralEntry, isEntryValid);
            PassGeneralEntry = new Command(passGeneralEntry, (o) => Transactions.Count > 0);
            AddAdjustmentEntry = new Command(addAdjustmentEntry, (o) => true);
            PassAdjustmentEntry = new Command(passAdjustmentEntry, (o) => Adjustments.Count > 0);
        }

        void subLedgerAddedHandler(SubLedger obj)
        {
            if (obj.ControlId == MainVM.ControlLedgers.First(x => x.Name == ControlName.Cash).Id)
            {
                CashAccounts.Add(obj);
                SelectedCashAccount = obj;
            }
        }

        void iconChangedHandler(Icon obj)
        {
            if (obj.Name == Constants.Transact)
                setRelevantControls(Head);
        }

        void setRelevantControls(HeadType head)
        {
            int id1, id2;
            id1 = id2 = 0;
            switch (head)
            {
                case HeadType.Asset:
                    id1 = MainVM.Books.First(x => x.Name == BookName.CurrentAsset).Id;
                    id2 = MainVM.Books.First(x => x.Name == BookName.NonCurrentAsset).Id;
                    break;
                case HeadType.Liability:
                    id1 = MainVM.Books.First(x => x.Name == BookName.CurrentLiability).Id;
                    id2 = MainVM.Books.First(x => x.Name == BookName.NonCurrentLiability).Id;
                    break;
                case HeadType.Income:
                    id1 = MainVM.Books.First(x => x.Name == BookName.Income).Id;
                    break;
                case HeadType.Expense:
                    id1 = MainVM.Books.First(x => x.Name == BookName.Expense).Id;
                    break;
                case HeadType.Fund:
                    id1 = MainVM.Books.First(x => x.Name == BookName.Fund).Id;
                    break;
            }
            RelevantControls = MainVM.ControlLedgers.Where(x => x.BookId == id1 || x.BookId == id2).ToList();
            MainVM.SelectedControlLedger = RelevantControls.FirstOrDefault();
        }

        void addGeneralEntry(object o)
        {
            Transactions.Add(Transaction);

            if (!IsPositive)
            {
                // Expense/Asset/Liability/Fund              Dr
                Transaction.DrBook = MainVM.SelectedControlLedger.BookId;
                Transaction.DrControl = MainVM.SelectedControlLedger.Id;
                Transaction.DrLedger = MainVM.SelectedLedger == null ? 0 : MainVM.SelectedLedger.Id;
                Transaction.DrSubLedger = MainVM.SelectedSubLedger == null ? 0 : MainVM.SelectedSubLedger.Id;
                if (Head == HeadType.Liability || Head == HeadType.Fund) setPersonalInfo(Transaction, true);

                if (Head != HeadType.Liability && Head != HeadType.Fund)
                {
                    // Payable                          Cr
                    var payable = MainVM.Ledgers.First(x => x.ControlId == payables.Id && x.Name == MainVM.SelectedControlLedger.Name);
                    Transaction.CrBook = payable.BookId;
                    Transaction.CrControl = payable.ControlId;
                    Transaction.CrLedger = payable.Id;
                    setPersonalInfo(Transaction, false);

                    if(TransactionMode != TransactionType.Credit)
                    {
                        /* Payable                      Dr
                         *      Cash                    Cr */
                        var payment = new Transaction()
                        {
                            Date = Transaction.Date,
                            DrBook = payable.BookId,
                            DrControl = payable.ControlId,
                            DrLedger = payable.Id,
                            CrBook = SelectedCashAccount.BookId,
                            CrControl = SelectedCashAccount.ControlId,
                            CrLedger = SelectedCashAccount.LedgerId,
                            CrSubLedger = SelectedCashAccount.Id,
                            Amount = TransactionMode == TransactionType.Cash ? Transaction.Amount : InCash
                        };
                        setPersonalInfo(payment, true);
                        Transactions.Add(payment);
                    }
                }
                else
                {
                    // Cash                         Cr
                    Transaction.CrBook = SelectedCashAccount.BookId;
                    Transaction.CrControl = SelectedCashAccount.ControlId;
                    Transaction.CrLedger = SelectedCashAccount.LedgerId;
                    Transaction.CrSubLedger = SelectedCashAccount.Id;
                }
            }
            else
            {
                // Income/Fund/Liability              Cr
                Transaction.CrBook = MainVM.SelectedControlLedger.BookId;
                Transaction.CrControl = MainVM.SelectedControlLedger.Id;
                Transaction.CrLedger = MainVM.SelectedLedger == null ? 0 : MainVM.SelectedLedger.Id;
                Transaction.CrSubLedger = MainVM.SelectedSubLedger == null ? 0 : MainVM.SelectedSubLedger.Id;
                if (Head != HeadType.Income) setPersonalInfo(Transaction, false);

                if(Head == HeadType.Income)
                {
                    // Receivable                       Dr
                    var receivable = MainVM.Ledgers.First(x => x.ControlId == receivables.Id && x.Name == MainVM.SelectedControlLedger.Name);
                    Transaction.DrBook = receivable.BookId;
                    Transaction.DrControl = receivable.ControlId;
                    Transaction.DrLedger = receivable.Id;
                    setPersonalInfo(Transaction, true);

                    if (TransactionMode != TransactionType.Credit)
                    {
                        /* Cash                         Dr
                         *      Receivable              Cr */
                        var receipt = new Transaction()
                        {
                            Date = Transaction.Date,
                            CrBook = receivable.BookId,
                            CrControl = receivable.ControlId,
                            CrLedger = receivable.Id,
                            DrBook = SelectedCashAccount.BookId,
                            DrControl = SelectedCashAccount.ControlId,
                            DrLedger = SelectedCashAccount.LedgerId,
                            DrSubLedger = SelectedCashAccount.Id,
                            Amount = TransactionMode == TransactionType.Cash ? Transaction.Amount : InCash
                        };
                        setPersonalInfo(receipt, false);
                        Transactions.Add(receipt);
                    }
                }
                else
                {
                    // Cash                         Dr
                    Transaction.DrBook = SelectedCashAccount.BookId;
                    Transaction.DrControl = SelectedCashAccount.ControlId;
                    Transaction.DrLedger = SelectedCashAccount.LedgerId;
                    Transaction.DrSubLedger = SelectedCashAccount.Id;
                }
            }

            Transaction = new Transaction() { Date = DateTime.Today };

            void setPersonalInfo(Transaction t, bool isDebit)
            {
                if (isDebit)
                {
                    if (IsMember) t.DrMember = MainVM.SelectedMember.Id;
                    else
                    {
                        t.DrPartyGroup = MainVM.SelectedParty.GroupId;
                        t.DrParty = MainVM.SelectedParty.Id;
                    }
                }
                else
                {
                    if (IsMember) t.CrMember = MainVM.SelectedMember.Id;
                    else
                    {
                        t.CrPartyGroup = MainVM.SelectedParty.GroupId;
                        t.CrParty = MainVM.SelectedParty.Id;
                    }
                }
            }
        }

        void addAdjustmentEntry(object o)
        {
            AdjustmentEntry.DrBook = Adjust.Debit.Control.BookId;
            AdjustmentEntry.DrControl = Adjust.Debit.Control.Id;
            AdjustmentEntry.DrLedger = Adjust.Debit.Ledger == null ? 0 : Adjust.Debit.Ledger.Id;
            AdjustmentEntry.DrSubLedger = Adjust.Debit.SubLedger == null ? 0 : Adjust.Debit.SubLedger.Id;
            switch (Adjust.Debit.Person)
            {
                case AdjustmentPersonType.Party:
                    AdjustmentEntry.DrPartyGroup = Adjust.Debit.Party.GroupId;
                    AdjustmentEntry.DrParty = Adjust.Debit.Party.Id;
                    break;
                case AdjustmentPersonType.Member: AdjustmentEntry.DrMember = Adjust.Debit.Member.Id; break;
            }

            AdjustmentEntry.CrBook = Adjust.Credit.Control.BookId;
            AdjustmentEntry.CrControl = Adjust.Credit.Control.Id;
            AdjustmentEntry.CrLedger = Adjust.Credit.Ledger == null ? 0 : Adjust.Credit.Ledger.Id;
            AdjustmentEntry.CrSubLedger = Adjust.Credit.SubLedger == null ? 0 : Adjust.Credit.SubLedger.Id;
            switch (Adjust.Credit.Person)
            {
                case AdjustmentPersonType.Party:
                    AdjustmentEntry.CrPartyGroup = Adjust.Credit.Party.GroupId;
                    AdjustmentEntry.CrParty = Adjust.Credit.Party.Id;
                    break;
                case AdjustmentPersonType.Member: AdjustmentEntry.CrMember = Adjust.Credit.Member.Id; break;
            }
            AdjustmentEntry.Date = Adjust.Date;
            AdjustmentEntry.Amount = Adjust.Amount;
            AdjustmentEntry.Narration = Adjust.Narration;
            Adjustments.Add(AdjustmentEntry);
        }

        void passGeneralEntry(object o) => passEntry(Transactions);

        void passAdjustmentEntry(object o) => passEntry(Adjustments);

        void passEntry(OCollection<Transaction> transactions)
        {     
            var commands = new List<SqliteCommand>(transactions.Count);
            foreach (var journal in transactions)
            {
                var commandText = $@"INSERT INTO Transactions VALUES({++MainVM.maxTramsactionId}, '{journal.Date.ToString("yyyy-MM-dd")}', {journal.DrBook}, {journal.CrBook}, {journal.DrControl}, {journal.CrControl},
                                     @DrLedger, @CrLedger, @DrSubLedger, @CrSubLedger, @DrPartyGroup, @CrPartyGroup, @DrParty, @CrParty, @DrMember, @CrMember, {journal.Amount}, @Narration)";
                var command = new SqliteCommand(commandText);
                command.Parameters.AddWithValue("@DrLedger", setSQLParameter(journal.DrLedger));
                command.Parameters.AddWithValue("@CrLedger", setSQLParameter(journal.CrLedger));
                command.Parameters.AddWithValue("@DrSubLedger", setSQLParameter(journal.DrSubLedger));
                command.Parameters.AddWithValue("@CrSubLedger", setSQLParameter(journal.CrSubLedger));
                command.Parameters.AddWithValue("@DrPartyGroup", setSQLParameter(journal.DrPartyGroup));
                command.Parameters.AddWithValue("@CrPartyGroup", setSQLParameter(journal.CrPartyGroup));
                command.Parameters.AddWithValue("@DrParty", setSQLParameter(journal.DrParty));
                command.Parameters.AddWithValue("@CrParty", setSQLParameter(journal.CrParty));
                command.Parameters.AddWithValue("@DrMember", setSQLParameter(journal.DrMember));
                command.Parameters.AddWithValue("@CrMember", setSQLParameter(journal.CrMember));
                command.Parameters.AddWithValue("@Narration", setSQLParameter(journal.Narration));
                commands.Add(command);
            }
            SQLHelper.Transaction(commands);
            transactions.Clear();
        }

        object setSQLParameter(object value)
        {
            if (value is int) return (int)value == 0 ? (object)DBNull.Value : value;
            else return string.IsNullOrWhiteSpace((string)value) ? (object)DBNull.Value : value;
        }

        bool isEntryValid(object o)
        {
            return TransactionMode switch
            {
                TransactionType.Cash => isCashEntryValid(),
                TransactionType.Credit => isCreditEntryValid(),
                TransactionType.Both => isBothEntryValid(),
            };
        }

        bool isCashEntryValid()
        {
            return SelectedCashAccount != null &&
                Transaction.Amount > 0 &&
                MainVM.SelectedControlLedger != null &&
                (IsMember ? MainVM.SelectedMember != null : MainVM.SelectedParty != null);

        }

        bool isCreditEntryValid()
        {
            return Transaction.Amount > 0 &&
               MainVM.SelectedControlLedger != null &&
               (IsMember ? MainVM.SelectedMember != null : MainVM.SelectedParty != null);
        }

        bool isBothEntryValid()
        {
            return isCashEntryValid() &&
                InCash > 0 &&
                InCash < Transaction.Amount;
        }
        
        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
