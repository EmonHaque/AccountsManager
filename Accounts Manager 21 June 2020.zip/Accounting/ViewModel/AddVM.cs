﻿using Accounting.Common;
using Accounting.Model;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace Accounting.ViewModel
{
    public class AddVM : INotifyPropertyChanged
    {
        ControlLedger newControlLedger;
        Ledger newLedger;
        SubLedger newSubLedger;
        PartyGroup newPartyGroup;
        Party newParty;
        Member newMember;

        public ControlLedger NewControlLedger { get => newControlLedger; set { newControlLedger = value; OnPropertyChanged(); } }       
        public Ledger NewLedger { get => newLedger; set { newLedger = value; OnPropertyChanged(); } }       
        public SubLedger NewSubLedger { get => newSubLedger; set { newSubLedger = value; OnPropertyChanged(); } }       
        public PartyGroup NewPartyGroup { get => newPartyGroup; set { newPartyGroup = value; OnPropertyChanged(); } }       
        public Party NewParty { get => newParty; set { newParty = value; OnPropertyChanged(); } }       
        public Member NewMember { get => newMember; set { newMember = value; OnPropertyChanged(); } }

        public Command AddControlLedger { get; set; }
        public Command AddLedger { get; set; }
        public Command AddSubLedger { get; set; }
        public Command AddPartyGroup { get; set; }
        public Command AddParty { get; set; }
        public Command AddMember { get; set; }

        public static event Action<SubLedger> OnSubLedgerAdded;

        public AddVM()
        {
            subscribe();
            initializeProperties();
            initializeCommands();
        }

        void subscribe()
        {
            MainVM.OnSelectedBookChanged += bookChangedHandler;
            MainVM.OnSelectedControlLedgerChanged += controlLedgerChangedHandler;
            MainVM.OnSelectedLedgerChanged += ledgerChangedHandler;
            MainVM.OnSelectedPartyGroupChanged += partyGroupChangedHandler;
            MainVM.OnSelectedIconChanged += iconChangedHandler;
        }

        

        #region Event Handlers
        void partyGroupChangedHandler(PartyGroup obj)
        {
            NewParty.GroupId = obj.Id;
        }

        void ledgerChangedHandler(Ledger obj)
        {
            NewSubLedger.LedgerId = obj.Id;
        }

        void controlLedgerChangedHandler(ControlLedger obj)
        {
            NewLedger.ControlId = obj.Id;
            NewSubLedger.ControlId = obj.Id;
        }

        void bookChangedHandler(Book obj)
        {
            NewControlLedger.BookId = obj.Id;
            NewLedger.BookId = obj.Id;
            NewSubLedger.BookId = obj.Id;
        }

        void iconChangedHandler(Icon obj)
        {
            if (obj.Name == Constants.Add)
                MainVM.SelectedControlLedger = MainVM.ControlLedgers.FirstOrDefault(x => x.BookId == MainVM.SelectedBook.Id);
        }
        #endregion

        void initializeCommands()
        {
            AddControlLedger = new Command(addControlLedger, (o) => NewControlLedger.IsInsertValid());
            AddLedger = new Command(addLedger, (o) => NewLedger.IsInsertValid());
            AddSubLedger = new Command(addSubLedger, (o) => NewSubLedger.IsInsertValid());
            AddPartyGroup = new Command(addPartyGroup, (o) => NewPartyGroup.IsInsertValid());
            AddParty = new Command(addParty, (o) => NewParty.IsInsertValid());
            AddMember = new Command(addMember, (o) => NewMember.IsInsertValid());
        }

        void initializeProperties()
        {
            renewControlLedger();
            renewLedger();
            renewSubLedger();
            NewMember = new Member();
            NewPartyGroup = new PartyGroup();
            NewParty = new Party() { GroupId = MainVM.SelectedPartyGroup.Id };
        }

        #region Icommand Executives
        void addControlLedger(object o)
        {
            NewControlLedger.Id = ++MainVM.maxControlLedgerId;
            var commands = new List<SqliteCommand>();
            var incomeId = MainVM.Books.First(x => x.Name == BookName.Income).Id;
            var expenseId = MainVM.Books.First(x => x.Name == BookName.Expense).Id;
            var assetId = MainVM.Books.First(x => x.Name == BookName.NonCurrentAsset).Id;

            if(NewControlLedger.BookId == incomeId || NewControlLedger.BookId == expenseId || NewControlLedger.BookId == assetId)
            {
                NewLedger = new Ledger() { Id = ++MainVM.maxLedgerId, Name = NewControlLedger.Name };
                if(NewControlLedger.BookId == incomeId)
                {
                    var receivableControl = MainVM.ControlLedgers.First(x => x.Name == ControlName.Receivable);
                    NewLedger.BookId = receivableControl.BookId;
                    NewLedger.ControlId = receivableControl.Id;
                   
                }
                else
                {
                    var payableControl = MainVM.ControlLedgers.First(x => x.Name == ControlName.Payable);
                    NewLedger.BookId = payableControl.BookId;
                    NewLedger.ControlId = payableControl.Id;
                }
                using var command1 = new SqliteCommand($"INSERT INTO Ledgers(BookId, ControlId, Name, Description) VALUES({NewLedger.BookId}, {NewLedger.ControlId}, '{NewLedger.Name}', @Description)");
                command1.Parameters.AddWithValue("@Description", DBNull.Value);
                commands.Add(command1);
                MainVM.Ledgers.Add(NewLedger);
                MainVM.ChartOfAccounts.First(x => x.Book.Id == NewLedger.BookId)
                                 .ControlLedgers.First(x => x.ControlLedger.Id == NewLedger.ControlId)
                                 .Ledgers.Add(new Ledgers() { Ledger = NewLedger });
                renewLedger();

            }
            var command2 = new SqliteCommand($"INSERT INTO ControlLedgers(BookId, Name) VALUES({NewControlLedger.BookId}, @Name)");
            command2.Parameters.AddWithValue("@Name", NewControlLedger.Name);
            commands.Add(command2);
            SQLHelper.Transaction(commands);

            MainVM.ControlLedgers.Add(NewControlLedger);
            MainVM.FilteredControlLedgers.Add(NewControlLedger);
            MainVM.SelectedControlLedger = NewControlLedger;

            MainVM.ChartOfAccounts.First(x => x.Book.Id == NewControlLedger.BookId)
                                  .ControlLedgers.Add(new ControlLedgers() { ControlLedger = NewControlLedger });
            renewControlLedger();
        }

        void addLedger(object o)
        {
            NewLedger.Id = ++MainVM.maxLedgerId;
            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText = $"INSERT INTO Ledgers(BookId, ControlId, Name, Description) VALUES({NewLedger.BookId}, {NewLedger.ControlId}, @Name, @Description)";
            command.Parameters.AddWithValue("@Name", NewLedger.Name);
            command.Parameters.AddWithValue("@Description", NewLedger.Description);
            SQLHelper.NonQuery(command);

            MainVM.Ledgers.Add(NewLedger);
            MainVM.FilteredLedgers.Add(NewLedger);
            MainVM.SelectedLedger = NewLedger;

            MainVM.ChartOfAccounts.First(x => x.Book.Id == NewLedger.BookId)
                                  .ControlLedgers.First(x => x.ControlLedger.Id == NewLedger.ControlId)
                                  .Ledgers.Add(new Ledgers() { Ledger = NewLedger });
            renewLedger();
        }

        void addSubLedger(object o)
        {
            NewSubLedger.Id = ++MainVM.maxSubLedgerId;
            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText = $"INSERT INTO SubLedgers(BookId, ControlId, LedgerId, Name, Description) VALUES({NewSubLedger.BookId}, {NewSubLedger.ControlId}, {NewSubLedger.LedgerId}, @Name, @Description)";
            command.Parameters.AddWithValue("@Name", NewSubLedger.Name);
            command.Parameters.AddWithValue("@Description", NewSubLedger.Description);
            SQLHelper.NonQuery(command);

            MainVM.SubLedgers.Add(NewSubLedger);
            MainVM.FilteredSubLedgers.Add(NewSubLedger);
            MainVM.SelectedSubLedger = NewSubLedger;

            MainVM.ChartOfAccounts.First(x => x.Book.Id == NewSubLedger.BookId)
                                  .ControlLedgers.First(x => x.ControlLedger.Id == NewSubLedger.ControlId)
                                  .Ledgers.First(x => x.Ledger.Id == NewSubLedger.LedgerId)
                                  .SubLedgers.Add(NewSubLedger);
            OnSubLedgerAdded?.Invoke(NewSubLedger);
            renewSubLedger();

        }

        void addPartyGroup(object o)
        {
            NewPartyGroup.Id = ++MainVM.maxPartyGroupId;
            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText = $"INSERT INTO PartyGroups(Name) VALUES(@Name)";
            command.Parameters.AddWithValue("@Name", NewPartyGroup.Name);
            SQLHelper.NonQuery(command);

            MainVM.PartyGroups.Add(NewPartyGroup);
            MainVM.SelectedPartyGroup = NewPartyGroup;

            NewPartyGroup = new PartyGroup();
        }

        void addParty(object o)
        {
            NewParty.Id = ++MainVM.maxPartyId;
            var address = string.IsNullOrWhiteSpace(NewParty.Address) ? (object)DBNull.Value : NewParty.Address;
            var contactNo = string.IsNullOrWhiteSpace(NewParty.ContactNo) ? (object)DBNull.Value : NewParty.ContactNo;
            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText = $"INSERT INTO Parties(GroupId, Name, Address, ContactNo) VALUES({NewParty.GroupId}, @Name, @Address, @ContactNo)";
            command.Parameters.AddWithValue("@Name", NewParty.Name);
            command.Parameters.AddWithValue("@Address", address);
            command.Parameters.AddWithValue("@ContactNo", contactNo);
            SQLHelper.NonQuery(command);

            MainVM.Parties.Add(newParty);
            MainVM.SelectedParty = NewParty;

            NewParty = new Party() { GroupId = MainVM.SelectedPartyGroup.Id };
        }

        void addMember(object o)
        {
            NewMember.Id = ++MainVM.maxMemberId;
            var contactNo = string.IsNullOrWhiteSpace(NewMember.ContactNo) ? (object)DBNull.Value : NewMember.ContactNo;
            using var command = SQLHelper.connection.CreateCommand();
            command.CommandText = $"INSERT INTO Members(Name, ContactNo) VALUES(@Name, @ContactNo)";
            command.Parameters.AddWithValue("@Name", NewMember.Name);
            command.Parameters.AddWithValue("@ContactNo", contactNo);
            SQLHelper.NonQuery(command);

            MainVM.Members.Add(NewMember);
            MainVM.SelectedMember = NewMember;

            NewMember = new Member();
        }
        #endregion

        #region Renew Properties
        void renewControlLedger()
        {
            NewControlLedger = new ControlLedger()
            {
                BookId = MainVM.SelectedBook.Id
            };
        }

        void renewLedger()
        {
            NewLedger = new Ledger()
            {
                BookId = MainVM.SelectedBook.Id,
                ControlId = MainVM.SelectedControlLedger.Id
            };
        }

        void renewSubLedger()
        {
            NewSubLedger = new SubLedger()
            {
                BookId = MainVM.SelectedBook.Id,
                ControlId = MainVM.SelectedControlLedger.Id,
                LedgerId = MainVM.SelectedLedger == null ? 0 : MainVM.SelectedLedger.Id
            };
        }

        #endregion

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        #endregion
    }

}
