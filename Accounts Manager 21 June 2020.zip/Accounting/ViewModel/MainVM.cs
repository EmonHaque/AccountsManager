﻿using Accounting.Common;
using Accounting.Model;
using Accounting.View;
using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

namespace Accounting.ViewModel
{
    public class MainVM : INotifyPropertyChanged
    {
        public List<Icon> Icons { get; set; }
        public static OCollection<ChartOfAccount> ChartOfAccounts { get; set; }
        public static OCollection<Book> Books { get; set; }
        public static OCollection<ControlLedger> ControlLedgers { get; set; }
        public static OCollection<Ledger> Ledgers { get; set; }
        public static OCollection<SubLedger> SubLedgers { get; set; }
        public static OCollection<PartyGroup> PartyGroups { get; set; }
        public static OCollection<Party> Parties { get; set; }
        public static OCollection<Member> Members { get; set; }
        public static int maxControlLedgerId, maxLedgerId, maxSubLedgerId, maxPartyGroupId, maxPartyId, maxMemberId, maxTramsactionId;

        static Icon selectedIcon;
        static OCollection<ControlLedger> filteredControlLedgers;
        static OCollection<Ledger> filteredLedgers;
        static OCollection<SubLedger> filteredSubLedgers;

        static Book selectedBook;
        static ControlLedger selectedControlLedger;
        static Ledger selectedLedger;
        static SubLedger selectedSubLedger;
        static PartyGroup selectedPartyGroup;
        static Party selectedParty;
        static Member selectedMember;

        public static Book SelectedBook 
        {
            get => selectedBook; 
            set 
            { 
                selectedBook = value; 
                OnStaticPropertyChanged();
                if(value != null)
                {
                    App.Current.Dispatcher.Invoke(() => FilteredControlLedgers = new OCollection<ControlLedger>(ControlLedgers.Where(x => x.BookId == value.Id)));
                    SelectedControlLedger = FilteredControlLedgers.FirstOrDefault();
                    OnSelectedBookChanged?.Invoke(value);
                }
                else
                {
                    FilteredControlLedgers = null;
                    SelectedControlLedger = null;
                }
            } 
        }       
        public static ControlLedger SelectedControlLedger 
        { 
            get => selectedControlLedger; 
            set 
            { 
                selectedControlLedger = value; 
                OnStaticPropertyChanged();
                if(value != null)
                {
                    App.Current.Dispatcher.Invoke(() => FilteredLedgers = new OCollection<Ledger>(Ledgers.Where(x => x.ControlId == value.Id)));
                    SelectedLedger = FilteredLedgers.FirstOrDefault();
                    OnSelectedControlLedgerChanged?.Invoke(value);
                }
                else
                {
                    FilteredLedgers = null;
                    SelectedLedger = null;
                }
            } 
        }      
        public static Ledger SelectedLedger 
        { 
            get => selectedLedger; 
            set 
            { 
                selectedLedger = value; 
                OnStaticPropertyChanged();
                if(value != null)
                {
                    App.Current.Dispatcher.Invoke(() => FilteredSubLedgers = new OCollection<SubLedger>(SubLedgers.Where(x => x.LedgerId == value.Id)));
                    SelectedSubLedger = FilteredSubLedgers.FirstOrDefault();
                    OnSelectedLedgerChanged?.Invoke(value);
                }
                else
                {
                    FilteredSubLedgers = null;
                    SelectedSubLedger = null;
                }
            } 
        }       
        public static SubLedger SelectedSubLedger { get => selectedSubLedger; set { selectedSubLedger = value; OnStaticPropertyChanged(); if (value != null) OnSelectedSubLedgerChanged?.Invoke(value); } }      
        public static PartyGroup SelectedPartyGroup { get => selectedPartyGroup; set { selectedPartyGroup = value; OnStaticPropertyChanged(); if (value != null) OnSelectedPartyGroupChanged?.Invoke(value); } }      
        public static Party SelectedParty { get => selectedParty; set { selectedParty = value; OnStaticPropertyChanged(); if (value != null) OnSelectedPartyChanged?.Invoke(value); } }       
        public static Member SelectedMember { get => selectedMember; set { selectedMember = value; OnStaticPropertyChanged(); if (value != null) OnSelectedMemberChanged?.Invoke(value); } }

        public static OCollection<ControlLedger> FilteredControlLedgers { get => filteredControlLedgers; set { filteredControlLedgers = value; OnStaticPropertyChanged(); } }      
        public static OCollection<Ledger> FilteredLedgers { get => filteredLedgers; set { filteredLedgers = value; OnStaticPropertyChanged(); } }    
        public static OCollection<SubLedger> FilteredSubLedgers { get => filteredSubLedgers; set { filteredSubLedgers = value; OnStaticPropertyChanged(); } }     
        public static Icon SelectedIcon
        {
            get => selectedIcon;
            set
            {
                selectedIcon = value;
                OnStaticPropertyChanged();
                if (value != null) OnSelectedIconChanged?.Invoke(value);
            }
        }

        public static event Action<Icon> OnSelectedIconChanged;
        public static event Action<Book> OnSelectedBookChanged;
        public static event Action<ControlLedger> OnSelectedControlLedgerChanged;
        public static event Action<Ledger> OnSelectedLedgerChanged;
        public static event Action<SubLedger> OnSelectedSubLedgerChanged;
        public static event Action<PartyGroup> OnSelectedPartyGroupChanged;
        public static event Action<Party> OnSelectedPartyChanged;
        public static event Action<Member> OnSelectedMemberChanged;

        public MainVM()
        {
            initializeCollections();
            checkDatabase();
            initializeMaxIds();
            initializeProperties();
            initializeIcons();

            App.Current.MainWindow.MouseDown += move;
            MaxRestoreTip = "Maximize";
            MaxRestoreIcon = Constants.MaximizeIcon;
            initializeCommands();
        }

        void initializeCollections()
        {
            Books = new OCollection<Book>();
            ControlLedgers = new OCollection<ControlLedger>();
            Ledgers = new OCollection<Ledger>();
            SubLedgers = new OCollection<SubLedger>();
            PartyGroups = new OCollection<PartyGroup>();
            Parties = new OCollection<Party>();
            Members = new OCollection<Member>();
            ChartOfAccounts = new OCollection<ChartOfAccount>();
        }

        void initializeProperties()
        {
            SelectedBook = Books.First();
            SelectedPartyGroup = PartyGroups.First();
            SelectedParty = Parties.FirstOrDefault();
            SelectedMember = Members.FirstOrDefault();
        }

        void initializeCommands()
        {
            Close = new Command(close, (o) => true);
            Minimize = new Command(minimize, (o) => true);
            MaxRestore = new Command(maxRestore, (o) => true);
        }

        void initializeIcons()
        {
            Icons = new List<Icon>()
            {
                new Icon(Constants.Home, Constants.HomeDescription, new HomeView(), Constants.HomeIcon),
                new Icon(Constants.Add, Constants.AddDescription, new AddView(), Constants.AddIcon),
                new Icon(Constants.Edit, Constants.EditDescription, new EditView(), Constants.EditIcon),
                new Icon(Constants.Transact, Constants.TransactDescription, new TransactView(), Constants.TransactIcon),
                new Icon(Constants.Report, Constants.LedgerDescription, new ReportView(), Constants.ReportIcon)
            };
            SelectedIcon = Icons.First();
        }

        void initializeMaxIds()
        {
            maxControlLedgerId = ControlLedgers.Max(x => x.Id);
            maxLedgerId = Ledgers.Count > 0 ? Ledgers.Max(x => x.Id) : 0;
            maxSubLedgerId = SubLedgers.Count > 0 ? SubLedgers.Max(x => x.Id) : 0;
            maxPartyGroupId = PartyGroups.Max(x => x.Id);
            maxPartyId = Parties.Count > 0 ? Parties.Max(x => x.Id) : 0;
            maxMemberId = Members.Count > 0 ? Members.Max(x => x.Id) : 0;
        }

        #region Create or Get Data from Database
        void checkDatabase()
        {
            if (!File.Exists(Constants.DBName)) createDatabase();
            else populateCollections();
        }

		void createDatabase()
		{
			using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Accounting.SQL.CreateDB.sql");
			using var sReader = new StreamReader(stream);
			SQLHelper.NonQuery(sReader.ReadToEnd());

			using var cmd = SQLHelper.connection.CreateCommand();
			cmd.CommandText = @"SELECT * FROM Books;
								SELECT * FROM ControlLedgers;
								SELECT * FROM PartyGroups;";
			SQLHelper.connection.Open();
			var reader = cmd.ExecuteReader();
            populateBooks(reader);
			reader.NextResult();
            populateControlLedgers(reader);
            reader.NextResult();
            populatePartyGroups(reader);
			SQLHelper.connection.Close();

            // Create relevant Receivables and Payables for Icome/Expense/NonCurrentAssets

            var receivableControl = ControlLedgers.First(x => x.Name == ControlName.Receivable);
            var payableControl = ControlLedgers.First(x => x.Name == ControlName.Payable);

            var incomeControls = ControlLedgers.Where(x => x.BookId == Books.First(x => x.Name == BookName.Income).Id);
            var expenseAndAssetControls = ControlLedgers.Where(x => x.BookId == Books.First(x => x.Name == BookName.Expense).Id || x.BookId == Books.First(x => x.Name == BookName.NonCurrentAsset).Id);

            var commands = new List<SqliteCommand>();
            foreach (var item in incomeControls)
            {
                var receivable = new Ledger()
                {
                    Id = ++maxLedgerId,
                    BookId = receivableControl.BookId,
                    ControlId = receivableControl.Id,
                    Name = item.Name
                };
                using var command = new SqliteCommand($"INSERT INTO Ledgers(BookId, ControlId, Name, Description) VALUES({receivable.BookId}, {receivable.ControlId}, '{receivable.Name}', @Description)");
                command.Parameters.AddWithValue("@Description", DBNull.Value);
                commands.Add(command);
                Ledgers.Add(receivable);
            }
            foreach (var item in expenseAndAssetControls)
            {
                var payable = new Ledger()
                {
                    Id = ++maxLedgerId,
                    BookId = payableControl.BookId,
                    ControlId = payableControl.Id,
                    Name = item.Name
                };
                using var command = new SqliteCommand($"INSERT INTO Ledgers(BookId, ControlId, Name, Description) VALUES({payable.BookId}, {payable.ControlId}, '{payable.Name}', @Description)");
                command.Parameters.AddWithValue("@Description", DBNull.Value);
                commands.Add(command);
                Ledgers.Add(payable);
            }
            SQLHelper.Transaction(commands);
            chartAccounts();
            maxTramsactionId = 0;
		}

		void populateCollections()
		{
			using var cmd = SQLHelper.connection.CreateCommand();
			cmd.CommandText = @"SELECT * FROM Books;
								SELECT * FROM ControlLedgers;
								SELECT * FROM PartyGroups;
								SELECT * FROM Ledgers;
								SELECT * FROM SubLedgers;
								SELECT * FROM Parties;
								SELECT * FROM Members;
								SELECT MAX(Id) FROM Transactions;";

			SQLHelper.connection.Open();
			var reader = cmd.ExecuteReader();
            populateBooks(reader);
			reader.NextResult();
            populateControlLedgers(reader);
			reader.NextResult();
            populatePartyGroups(reader);

			reader.NextResult();
			while (reader.Read())
			{
                Ledgers.Add(new Ledger()
                {
                    Id = reader.GetInt32(0),
                    BookId = reader.GetInt32(1),
                    ControlId = reader.GetInt32(2),
                    Name = reader.GetString(3),
                    Description = reader.IsDBNull(4) ? null : reader.GetString(4)
                });
			}

			reader.NextResult();
			while (reader.Read())
			{
                SubLedgers.Add(new SubLedger()
                {
                    Id = reader.GetInt32(0),
                    BookId = reader.GetInt32(1),
                    ControlId = reader.GetInt32(2),
                    LedgerId = reader.GetInt32(3),
                    Name = reader.GetString(4),
                    Description = reader.IsDBNull(5) ? null : reader.GetString(5)
                });
            }

			reader.NextResult();
			while (reader.Read())
			{
                Parties.Add(new Party()
                {
                    Id = reader.GetInt32(0),
                    GroupId = reader.GetInt32(1),
                    Name = reader.GetString(2),
                    Address = reader.IsDBNull(3) ? null : reader.GetString(3),
                    ContactNo = reader.IsDBNull(4) ? null : reader.GetString(4)
                });
            }

            reader.NextResult();
            while (reader.Read())
            {
                Members.Add(new Member()
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1),
                    ContactNo = reader.IsDBNull(2) ? null : reader.GetString(2)
                });
            }

            reader.NextResult();
            reader.Read();
            maxTramsactionId = reader.IsDBNull(0) ? 0 : reader.GetInt32(0);
            SQLHelper.connection.Close();
            chartAccounts();
            
        }

        void chartAccounts()
        {
            foreach (var book in Books)
            {
                var ca = new ChartOfAccount() { Book = book };
                var cl = ControlLedgers.Where(x => x.BookId == book.Id);
                foreach (var control in cl)
                {
                    var ledgers = Ledgers.Where(x => x.ControlId == control.Id).ToList();
                    var cls = new ControlLedgers() { ControlLedger = control };
                    foreach (var le in ledgers)
                    {
                        cls.Ledgers.Add(new Model.Ledgers()
                        {
                            Ledger = le,
                            SubLedgers = new OCollection<SubLedger>(SubLedgers.Where(x => x.LedgerId == le.Id))
                        });
                    }
                    ca.ControlLedgers.Add(cls);
                }
                ChartOfAccounts.Add(ca);
            }
        }

        void populateBooks(SqliteDataReader reader)
        {
            while (reader.Read())
            {
                Books.Add(new Book()
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1)
                });
            }
        }

        void populateControlLedgers(SqliteDataReader reader)
        {
            while (reader.Read())
            {
                ControlLedgers.Add(new ControlLedger()
                {
                    Id = reader.GetInt32(0),
                    BookId = reader.GetInt32(1),
                    Name = reader.GetString(2)
                });
            }
        }

        void populatePartyGroups(SqliteDataReader reader)
        {
            while (reader.Read())
            {
                PartyGroups.Add(new PartyGroup()
                {
                    Id = reader.GetInt32(0),
                    Name = reader.GetString(1)
                });
            }
        }
        #endregion

        #region Window Handler
        public Command Close { get; set; }
        public Command Minimize { get; set; }
        public Command MaxRestore { get; set; }

        string maxRestoreIcon, maxRestoreTip;
        public string MaxRestoreIcon { get => maxRestoreIcon; set { maxRestoreIcon = value; OnPropertyChanged(); } }
        public string MaxRestoreTip { get => maxRestoreTip; set { maxRestoreTip = value; OnPropertyChanged(); } }

        void close(object o) => App.Current.Shutdown();

        void minimize(object o) => App.Current.MainWindow.WindowState = System.Windows.WindowState.Minimized;

        void maxRestore(object o)
        {
            switch (App.Current.MainWindow.WindowState)
            {
                case System.Windows.WindowState.Normal:
                    App.Current.MainWindow.WindowState = System.Windows.WindowState.Maximized;
                    MaxRestoreIcon = Constants.RestoreIcon;
                    MaxRestoreTip = "Restore";
                    break;
                case System.Windows.WindowState.Maximized:
                    App.Current.MainWindow.WindowState = System.Windows.WindowState.Normal;
                    MaxRestoreIcon = Constants.MaximizeIcon;
                    MaxRestoreTip = "Maximize";
                    break;
            }
        }

        void move(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (e.ChangedButton == System.Windows.Input.MouseButton.Left)
                App.Current.MainWindow.DragMove();
        }
        #endregion

        #region Notify Property Changed Members
        public event PropertyChangedEventHandler PropertyChanged;
        public static event PropertyChangedEventHandler StaticPropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = "") => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        static void OnStaticPropertyChanged([CallerMemberName] string name = "") => StaticPropertyChanged?.Invoke(null, new PropertyChangedEventArgs(name));
        #endregion
    }

}
