﻿using System.Windows;
using System.Windows.Controls.Primitives;

namespace Accounting.CustomControls
{
    public class ScrollButton : RepeatButton
    {
        static ScrollButton()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ScrollButton), new FrameworkPropertyMetadata(typeof(ScrollButton)));
        }

        public string Geometry
        {
            get { return (string)GetValue(GeometryProperty); }
            set { SetValue(GeometryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Geometry.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GeometryProperty =
            DependencyProperty.Register("Geometry", typeof(string), typeof(ScrollButton), new PropertyMetadata(null));
    }
}
