﻿using Accounting.Enum;
using Accounting.Model;
using Accounting.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Accounting.CustomControls
{
    public class AdjustControl : Control
    {
        static AdjustControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(AdjustControl), new FrameworkPropertyMetadata(typeof(AdjustControl)));
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            Controls = MainVM.ControlLedgers;
            Members = MainVM.Members;
            Parties = MainVM.Parties;
            SelectedControl = Controls.First();
            SelectedMember = Members.FirstOrDefault();
            SelectedParty = Parties.FirstOrDefault();
        }

        public string Header
        {
            get { return (string)GetValue(HeaderProperty); }
            set { SetValue(HeaderProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Header.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HeaderProperty =
            DependencyProperty.Register("Header", typeof(string), typeof(AdjustControl), new PropertyMetadata(null));



        public IEnumerable<ControlLedger> Controls
        {
            get { return (IEnumerable<ControlLedger>)GetValue(ControlsProperty); }
            set { SetValue(ControlsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Controls.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ControlsProperty =
            DependencyProperty.Register("Controls", typeof(IEnumerable<ControlLedger>), typeof(AdjustControl), new PropertyMetadata(null));


        public IEnumerable<Model.Ledger> Ledgers
        {
            get { return (IEnumerable<Model.Ledger>)GetValue(LedgersProperty); }
            set { SetValue(LedgersProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Ledgers.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LedgersProperty =
            DependencyProperty.Register("Ledgers", typeof(IEnumerable<Model.Ledger>), typeof(AdjustControl), new PropertyMetadata(null));


        public IEnumerable<SubLedger> Subledgers
        {
            get { return (IEnumerable<SubLedger>)GetValue(SubledgersProperty); }
            set { SetValue(SubledgersProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Subledgers.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SubledgersProperty =
            DependencyProperty.Register("Subledgers", typeof(IEnumerable<SubLedger>), typeof(AdjustControl), new PropertyMetadata(null));


        public IEnumerable<Member> Members
        {
            get { return (IEnumerable<Member>)GetValue(MembersProperty); }
            set { SetValue(MembersProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Members.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MembersProperty =
            DependencyProperty.Register("Members", typeof(IEnumerable<Member>), typeof(AdjustControl), new PropertyMetadata(null));


        public IEnumerable<Party> Parties
        {
            get { return (IEnumerable<Party>)GetValue(PartiesProperty); }
            set { SetValue(PartiesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Parties.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PartiesProperty =
            DependencyProperty.Register("Parties", typeof(IEnumerable<Party>), typeof(AdjustControl), new PropertyMetadata(null));



        public ControlLedger SelectedControl
        {
            get { return (ControlLedger)GetValue(SelectedControlProperty); }
            set { SetValue(SelectedControlProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedControl.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedControlProperty =
            DependencyProperty.Register("SelectedControl", typeof(ControlLedger), typeof(AdjustControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, onControlChanged));

        static void onControlChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var o = d as AdjustControl;
            o.Ledgers = MainVM.Ledgers.Where(x => x.ControlId == o.SelectedControl.Id);
            o.SelectedLedger = o.Ledgers.FirstOrDefault();
        }


        public Model.Ledger SelectedLedger
        {
            get { return (Model.Ledger)GetValue(SelectedLedgerProperty); }
            set { SetValue(SelectedLedgerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedLedger.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedLedgerProperty =
            DependencyProperty.Register("SelectedLedger", typeof(Model.Ledger), typeof(AdjustControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, onLedgerChanged));

        static void onLedgerChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var o = d as AdjustControl;
            o.Subledgers = o.SelectedLedger == null ? null : MainVM.SubLedgers.Where(x => x.LedgerId == o.SelectedLedger.Id);
            o.SelectedSubledger = o.Subledgers == null ? null : o.Subledgers.FirstOrDefault();
        }


        public SubLedger SelectedSubledger
        {
            get { return (SubLedger)GetValue(SelectedSubledgerProperty); }
            set { SetValue(SelectedSubledgerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedSubledger.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedSubledgerProperty =
            DependencyProperty.Register("SelectedSubledger", typeof(SubLedger), typeof(AdjustControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public Member SelectedMember
        {
            get { return (Member)GetValue(SelectedMemberProperty); }
            set { SetValue(SelectedMemberProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedMember.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedMemberProperty =
            DependencyProperty.Register("SelectedMember", typeof(Member), typeof(AdjustControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));



        public Party SelectedParty
        {
            get { return (Party)GetValue(SelectedPartyProperty); }
            set { SetValue(SelectedPartyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedParty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedPartyProperty =
            DependencyProperty.Register("SelectedParty", typeof(Party), typeof(AdjustControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));



        public AdjustmentPersonType Person
        {
            get { return (AdjustmentPersonType)GetValue(PersonProperty); }
            set { SetValue(PersonProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Person.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PersonProperty =
            DependencyProperty.Register("Person", typeof(AdjustmentPersonType), typeof(AdjustControl), new FrameworkPropertyMetadata(AdjustmentPersonType.Party, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));

    }
}
