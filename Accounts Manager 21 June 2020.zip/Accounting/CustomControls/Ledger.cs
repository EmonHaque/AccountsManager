﻿using System.Collections;
using System.Windows;
using System.Windows.Controls;

namespace Accounting.CustomControls
{
    public class Ledger : Control
    {
        static Ledger()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(Ledger), new FrameworkPropertyMetadata(typeof(Ledger)));
        }


        public IEnumerable Source
        {
            get { return (IEnumerable)GetValue(SourceProperty); }
            set { SetValue(SourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Source.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SourceProperty =
            DependencyProperty.Register("Source", typeof(IEnumerable), typeof(Ledger), new PropertyMetadata(null));


    }
}
