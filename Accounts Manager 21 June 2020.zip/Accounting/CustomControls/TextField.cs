﻿using System.Windows;
using System.Windows.Controls;

namespace Accounting.CustomControls
{
    public class TextField : Control
    {
        static TextField()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TextField), new FrameworkPropertyMetadata(typeof(TextField)));
        }


        public string Label
        {
            get { return (string)GetValue(LabelProperty); }
            set { SetValue(LabelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Label.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LabelProperty =
            DependencyProperty.Register("Label", typeof(string), typeof(TextField), new PropertyMetadata(null));


        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(TextField), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public bool AcceptReturn
        {
            get { return (bool)GetValue(AcceptReturnProperty); }
            set { SetValue(AcceptReturnProperty, value); }
        }

        // Using a DependencyProperty as the backing store for AcceptReturn.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AcceptReturnProperty =
            DependencyProperty.Register("AcceptReturn", typeof(bool), typeof(TextField), new PropertyMetadata(false, OnAcceptReturnChanged));

        static void OnAcceptReturnChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if ((bool)e.NewValue)
            {
                (d as TextField).TextWrap = TextWrapping.Wrap;
                (d as TextField).MinimumHeight = 60;
            }
        }

        public TextWrapping TextWrap
        {
            get { return (TextWrapping)GetValue(TextWrapProperty); }
            set { SetValue(TextWrapProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TextWrap.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TextWrapProperty =
            DependencyProperty.Register("TextWrap", typeof(TextWrapping), typeof(TextField), new PropertyMetadata(TextWrapping.NoWrap));


        public double MinimumHeight
        {
            get { return (double)GetValue(MinimumHeightProperty); }
            set { SetValue(MinimumHeightProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MinimumHeight.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MinimumHeightProperty =
            DependencyProperty.Register("MinimumHeight", typeof(double), typeof(TextField), new PropertyMetadata(0d));
    }
}
