﻿using Accounting.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Accounting.CustomControls
{
    public class TriState : CheckBox
    {
        static TriState()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TriState), new FrameworkPropertyMetadata(typeof(TriState)));
        }
        protected override void OnClick()
        {
            base.OnClick();
            switch (IsChecked)
            {
                case true: TransactionMode = TransactionType.Credit; break;
                case false: TransactionMode = TransactionType.Cash; break;
                case null: TransactionMode = TransactionType.Both; break;
            }
        }

        public TransactionType TransactionMode
        {
            get { return (TransactionType)GetValue(TransactionModeProperty); }
            set { SetValue(TransactionModeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TransactionMode.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TransactionModeProperty =
            DependencyProperty.Register("TransactionMode", typeof(TransactionType), typeof(TriState), new FrameworkPropertyMetadata(TransactionType.Cash, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));




    }
}
