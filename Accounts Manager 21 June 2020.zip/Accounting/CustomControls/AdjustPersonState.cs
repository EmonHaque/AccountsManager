﻿using Accounting.Enum;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Accounting.CustomControls
{
    public class AdjustPersonState : CheckBox
    {
        static AdjustPersonState()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(AdjustPersonState), new FrameworkPropertyMetadata(typeof(AdjustPersonState)));
        }

        protected override void OnClick()
        {
            base.OnClick();
            switch (IsChecked)
            {
                case true: State = AdjustmentPersonType.Member; break;
                case false: State = AdjustmentPersonType.Party; break;
                case null: State = AdjustmentPersonType.None; break;
            }
        }


        public AdjustmentPersonType State
        {
            get { return (AdjustmentPersonType)GetValue(StateProperty); }
            set { SetValue(StateProperty, value); }
        }

        // Using a DependencyProperty as the backing store for State.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty StateProperty =
            DependencyProperty.Register("State", typeof(AdjustmentPersonType), typeof(AdjustPersonState), new FrameworkPropertyMetadata(AdjustmentPersonType.Party, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));



    }
}
