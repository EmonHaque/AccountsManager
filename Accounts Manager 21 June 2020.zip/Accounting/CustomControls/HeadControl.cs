﻿using Accounting.Enum;
using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Accounting.CustomControls
{
    public class HeadControl : Control
    {
        static HeadControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(HeadControl), new FrameworkPropertyMetadata(typeof(HeadControl)));
        }
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            var check = GetTemplateChild("check") as TriState;
            check.Click += setMode;
            EventManager.RegisterClassHandler(typeof(Radio), Radio.CheckedEvent, new RoutedEventHandler(handleRadio));
        }

        void setMode(object sender, RoutedEventArgs e)
        {
            var x = sender as TriState;
            switch (x.IsChecked)
            {
                case true: Mode = TransactionType.Credit; break;
                case false: Mode = TransactionType.Cash; break;
                case null: Mode = TransactionType.Both; break;
            }
            setHead();
        }

        void handleRadio(object sender, RoutedEventArgs e)
        {
            setHead((sender as Radio).Content);
        }

        public bool IsPositive
        {
            get { return (bool)GetValue(IsPositiveProperty); }
            set { SetValue(IsPositiveProperty, value); }
        }


        public TransactionType Mode
        {
            get { return (TransactionType)GetValue(ModeProperty); }
            set { SetValue(ModeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Mode.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ModeProperty =
            DependencyProperty.Register("Mode", typeof(TransactionType), typeof(HeadControl), new FrameworkPropertyMetadata(TransactionType.Cash, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public HeadType SelectedHead
        {
            get { return (HeadType)GetValue(SelectedHeadProperty); }
            set { SetValue(SelectedHeadProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedHead.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedHeadProperty =
            DependencyProperty.Register("SelectedHead", typeof(HeadType), typeof(HeadControl), new FrameworkPropertyMetadata(HeadType.Expense, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));



        // Using a DependencyProperty as the backing store for IsPositive.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsPositiveProperty =
            DependencyProperty.Register("IsPositive", typeof(bool), typeof(HeadControl), new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, onChecked));

        static void onChecked(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            (d as HeadControl).setHead();
        }

        void setHead()
        {
            string panelName;
            if (IsPositive)
            {
                if (Mode == TransactionType.Cash) panelName = "positiveCash";
                else panelName = "positiveNonCash";
            }
            else
            {
                if (Mode == TransactionType.Cash) panelName = "negativeCash";
                else panelName = "negativeNonCash";
            }
            var panel = GetTemplateChild(panelName) as StackPanel;
            foreach (var radio in panel.Children)
            {
                var x = radio as Radio;
                if (x.IsChecked == true) setHead(x.Content);
            }
        }

        void setHead(object content)
        {
            switch (content)
            {
                case "Expense": SelectedHead = HeadType.Expense; break;
                case "Asset": SelectedHead = HeadType.Asset; break;
                case "Liability": SelectedHead = HeadType.Liability; break;
                case "Income": SelectedHead = HeadType.Income; break;
                case "Fund": SelectedHead = HeadType.Fund; break;
            }
        }
    }
}
