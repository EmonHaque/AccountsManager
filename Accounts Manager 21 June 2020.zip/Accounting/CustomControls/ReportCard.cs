﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Accounting.CustomControls
{
    public class ReportCard : ContentControl
    {
        static ReportCard()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ReportCard), new FrameworkPropertyMetadata(typeof(ReportCard)));
        }

        public string Header
        {
            get { return (string)GetValue(HeaderProperty); }
            set { SetValue(HeaderProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Header.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HeaderProperty =
            DependencyProperty.Register("Header", typeof(string), typeof(ReportCard), new PropertyMetadata(null, onHeaderChanged));

        static void onHeaderChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var o = d as ReportCard;
            if((string)e.NewValue == "Balance Sheet")
            {
                o.IsFromVisible = false;
                o.ToLabel = "as at";
                o.ToLabelWidth = 35;
            }
            else
            {
                o.IsFromVisible = true;
                o.ToLabel = "to";
                o.ToLabelWidth = 20;
            }
        }

        public bool IsBusy
        {
            get { return (bool)GetValue(IsBusyProperty); }
            set { SetValue(IsBusyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsBusy.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsBusyProperty =
            DependencyProperty.Register("IsBusy", typeof(bool), typeof(ReportCard), new PropertyMetadata(false));


        public string ToLabel
        {
            get { return (string)GetValue(ToLabelProperty); }
            set { SetValue(ToLabelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ToLabel.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ToLabelProperty =
            DependencyProperty.Register("ToLabel", typeof(string), typeof(ReportCard), new PropertyMetadata("to"));


        public double ToLabelWidth
        {
            get { return (double)GetValue(ToLabelWidthProperty); }
            set { SetValue(ToLabelWidthProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ToLabelWidth.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ToLabelWidthProperty =
            DependencyProperty.Register("ToLabelWidth", typeof(double), typeof(ReportCard), new PropertyMetadata(20d));


        public bool IsFromVisible
        {
            get { return (bool)GetValue(IsFromVisibleProperty); }
            set { SetValue(IsFromVisibleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsFromVisible.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsFromVisibleProperty =
            DependencyProperty.Register("IsFromVisible", typeof(bool), typeof(ReportCard), new PropertyMetadata(true));



        public DateTime FromDay
        {
            get { return (DateTime)GetValue(FromDayProperty); }
            set { SetValue(FromDayProperty, value); }
        }

        // Using a DependencyProperty as the backing store for FromDay.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FromDayProperty =
            DependencyProperty.Register("FromDay", typeof(DateTime), typeof(ReportCard), new FrameworkPropertyMetadata(DateTime.Today.AddMonths(-1), FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public DateTime ToDay
        {
            get { return (DateTime)GetValue(ToDayProperty); }
            set { SetValue(ToDayProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ToDay.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ToDayProperty =
            DependencyProperty.Register("ToDay", typeof(DateTime), typeof(ReportCard), new FrameworkPropertyMetadata(DateTime.Today, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));


        public ICommand RefreshCommand
        {
            get { return (ICommand)GetValue(RefreshCommandProperty); }
            set { SetValue(RefreshCommandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for RefreshCommand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RefreshCommandProperty =
            DependencyProperty.Register("RefreshCommand", typeof(ICommand), typeof(ReportCard), new PropertyMetadata(null));

    }
}
