﻿CREATE TABLE "Books" (
	"Id"	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"Name"	TEXT NOT NULL
);

CREATE TABLE "ControlLedgers" (
	"Id"	    INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"BookId"	INTEGER NOT NULL,
	"Name"	    INTEGER NOT NULL,

	FOREIGN KEY("BookId") REFERENCES "Books"("Id")
);

CREATE TABLE "Ledgers" (
	"Id"	        INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"BookId"	    INTEGER NOT NULL,
	"ControlId"     INTEGER NOT NULL,
	"Name"	        INTEGER NOT NULL,
	"Description"   TEXT,

	FOREIGN KEY("BookId") REFERENCES "Books"("Id"),
	FOREIGN KEY("ControlId") REFERENCES "ControlLedgers"("Id")
);

CREATE TABLE "SubLedgers" (
	"Id"	        INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"BookId"	    INTEGER NOT NULL,
	"ControlId"     INTEGER NOT NULL,
	"LedgerId"     INTEGER NOT NULL,
	"Name"	        INTEGER NOT NULL,
	"Description"   TEXT,

	FOREIGN KEY("BookId") REFERENCES "Books"("Id"),
	FOREIGN KEY("ControlId") REFERENCES "ControlLedgers"("Id"),
	FOREIGN KEY("LedgerId") REFERENCES "Ledgers"("Id")
);

CREATE TABLE "PartyGroups"(
	"Id"        INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"Name"      TEXT NOT NULL
);

CREATE TABLE "Parties"(
	"Id"        INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"GroupId"	INTEGER NOT NULL,
	"Name"      TEXT NOT NULL,
	"Address"   TEXT,
	"ContactNo" TEXT,

	FOREIGN KEY("GroupId") REFERENCES "PartyGroups"("Id")
);

CREATE TABLE "Members"(
	"Id"        INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	"Name"      TEXT NOT NULL,
	"ContactNo" TEXT
);

CREATE TABLE "Transactions"(
	"Id"			INTEGER NOT NULL,
	"Date"			TEXT NOT NULL,
	"DrBook"		INTEGER NOT NULL,
	"CrBook"		INTEGER NOT NULL,
	"DrControl"		INTEGER NOT NULL,
	"CrControl"		INTEGER NOT NULL,
	"DrLedger"		INTEGER,
	"CrLedger"		INTEGER,	
	"DrSubLedger"	INTEGER,
	"CrSubLedger"	INTEGER,
	"DrPartyGroup"	INTEGER,
	"CrPartyGroup"	INTEGER,
	"DrParty"		INTEGER,
	"CrParty"		INTEGER,
	"DrMember"		INTEGER,
	"CrMember"		INTEGER,
	"Amount"		INTEGER NOT NULL,
	"Narration"		TEXT,

	FOREIGN KEY("DrBook") REFERENCES "Books"("Id"),
	FOREIGN KEY("CrBook") REFERENCES "Books"("Id"),
	FOREIGN KEY("DrControl") REFERENCES "ControlLedgers"("Id"),
	FOREIGN KEY("CrControl") REFERENCES "ControlLedgers"("Id"),
	FOREIGN KEY("DrLedger") REFERENCES "Ledgers"("Id"),
	FOREIGN KEY("CrLedger") REFERENCES "Ledgers"("Id"),
	FOREIGN KEY("DrSubLedger") REFERENCES "SubLedgers"("Id"),
	FOREIGN KEY("CrSubLedger") REFERENCES "SubLedgers"("Id"),
	FOREIGN KEY("DrPartyGroup") REFERENCES PartyGroups("Id"),
	FOREIGN KEY("CrPartyGroup") REFERENCES PartyGroups("Id"),
	FOREIGN KEY("DrParty") REFERENCES "Parties"("Id"),
	FOREIGN KEY("CrParty") REFERENCES "Parties"("Id"),
	FOREIGN KEY("DrMember") REFERENCES "Members"("Id"),
	FOREIGN KEY("CrMember") REFERENCES "Members"("Id")	
);

INSERT INTO "PartyGroups" (Name) VALUES
	('Employee'),
	('Institution'),
	('Government'),
	('Other');

INSERT INTO "Books" (Name) VALUES
	('Non Current Assets'),
	('Current Assets'),
	('Expenses'),
	('Non Current Liabilities'),
	('Current Liabilities'),
	('Fund'),
	('Incomes');

INSERT INTO "ControlLedgers" (BookId, Name) VALUES
	(1, 'Land'),
	(1, 'Construction and Developments'),
	(1, 'Furniture and Fixtures'),
	(1, 'Equipments'),
	(1, 'Financial Assets'),

	(2, 'Cash'),
	(2, 'Receivables'),

	(3, 'Foods'),
	(3, 'Electricity'),
	(3, 'Gas'),
	(3, 'Water'),
	(3, 'Salaries'),
	(3, 'Repair and Maintenance'),
	(3, 'Gift and Donations'),

	(4, 'Loans'),
	(4, 'Advance and Security Monies'),

	(5, 'Payables'),

	(7, 'Rents'),
	(7, 'Scrap Sales'),
	(7, 'Others');